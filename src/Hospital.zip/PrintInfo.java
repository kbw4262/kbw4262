package Hospital;

public interface PrintInfo {

	abstract void printTotalRoom();
	void printRoomMaxPerson(int roomNumber);
}
